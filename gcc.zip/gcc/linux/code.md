# a.Create 5 empty files, empty1, empty 2, empty 3, empty is empty 5
```
google@cloudshell:~/test$ touch empty1 empty2 empty3 empty4 empty5

google@cloudshell:~/test$ ls

empty1  empty2  empty3  empty4  empty5
```
# b. Create a text file and store name, age, sex & address in it.
```
google@cloudshell:~/test$ vim personal_info.txt 

me: John Doe

Age: 30

Sex: Male

Address: 123 Main Street, Usa

Esc and  :wq for save and exit

google@cloudshell:~/test$ ls

 personal_info.txt
```

# C. display the file content on the screen 
```
google@cloudshell:~/test$ cat  personal_info.txt

me: John Doe

Age: 30

Sex: Male

Address: 123 Main Street, Usa
```

# d. Make a copy of the fill content into another text file.
```
google@cloudshell:~/test$ cat personal_info.txt > copied_info.txt

google@cloudshell:~/test$ cat copied_info.txt

me: John Doe

Age: 30

Sex: Male

Address: 123 Main Street, Usa
```

# e. Create a file new.txt and write any sentence in it
```
google@cloudshell:~/test$ echo "This is a sample sentence." > new.txt

google@cloudshell:~/test$ echo "This is the second sentence." >> new.txt

google@cloudshell:~/test$ cat new.txt

This is a sample sentence.

This is the second sentence.
```

# f. Rename the file to new.txt to old.txt
```
google@cloudshell:~/test$ mv new.txt old.txt

google@cloudshell:~/test$ ls

old.txt
```
# g. create a new directory called mydir inside current directory
```
google@cloudshell:~/test$ ls

old.txt

google@cloudshell:~/test$ mkdir mydir

google@cloudshell:~/test$ ls

mydir  old.txt
```
# h. Move old.txt file inside new directory mydir
```
google@cloudshell:~/test$ mv old.txt mydir/

google@cloudshell:~/test$ ls

mydir

google@cloudshell:~/test$ cd mydir

google@cloudshell:~/test/mydir$ ls

old.txt
```

# i.Copy the content of mydir to newdir
```
google@cloudshell:~/test$ ls

mydir

google@cloudshell:~/test$ cp -r mydir newdir

google@cloudshell:~/test$ ls

mydir  newdir
```
# j. Details interactively all empty file

```
google@cloudshell:~/test$ ls

a.txt  mydir  newdir

google@cloudshell:~/test$ find . -type f -empty -exec stat {} \;

  File: ./a.txt

  Size: 0               Blocks: 0          IO Block: 4096   regular empty file

Device: 811h/2065d      Inode: 131258      Links: 1

Access: (0644/-rw-r--r--)  Uid: ( 1000/google)   Gid: ( 1000/google)

Access: 2023-10-07 13:27:04.051418605 +0000

Modify: 2023-10-07 13:27:04.051418605 +0000

Change: 2023-10-07 13:27:04.051418605 +0000

 Birth: 2023-10-07 13:27:04.051418605 +0000
```

# 4. Suppose the path exists in your directory. (dir1/dir2/dir3/dir4) all these directories are empty. How do you remove all of them in one command****
```
google@cloudshell:~/test/dir1/dir2/dir3/dir4$ pwd

/home/google/test/dir1/dir2/dir3/dir4

google@cloudshell:~/test$ ls

dir1

google@cloudshell:~/test$ rm -rf dir1

google@cloudshell:~/test$ ls
```